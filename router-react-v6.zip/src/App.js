import React from 'react';
import { BrowserRouter, Route, Routes, Navigate } from 'react-router-dom';
import Navbar from './Navbar';
import About from './pages/About';
import Contact from './pages/Contact';
import Dashboard from './pages/Dashboard';
import Home from './pages/Home';
import Login from './pages/Login';
import Mobile from './pages/Mobile';

const App = () => {
  const isLogged = true;
  const data = {
    info: 'Please log-in',
  };
  return (
    <>
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path='/home' element={<Home />} />
          <Route path='/about' element={<About />} />
          <Route path='/contact' element={<Contact />} />
          <Route path='/mobile/:brand' element={<Mobile />} />
          <Route path='/mobile/:brand/:id' element={<Mobile />} />

          <Route path='/login' element={<Login />} />
          <Route path='/dashboard' element={isLogged ? <Dashboard /> : <Navigate to={'/login'} replace state={data} />} />

          {/* wild card for all other routes */}
          <Route path='*' element={<h1>Error 404 Page not found!!</h1>} />
        </Routes>
      </BrowserRouter>
    </>
  );
};

export default App;

// path -- '/'  or '/about' or '/contact'
