import React from 'react';
import { useParams, Outlet } from 'react-router-dom';

const Home = () => {
  const params = useParams();
  console.log(params);
  return (
    <div>
      <h3>home</h3>
      <Outlet />
    </div>
  );
};

export default Home;
