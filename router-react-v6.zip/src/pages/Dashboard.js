import React from 'react';
import { useNavigate } from 'react-router-dom';

const Dashboard = () => {
  const navigate = useNavigate();

  const logout = () => {
    navigate('/login', { state: { info: 'extra data' } });
  };

  return (
    <div>
      <h2>Dashboard Page</h2>
      <button onClick={logout}>Log out</button>
    </div>
  );
};

export default Dashboard;
