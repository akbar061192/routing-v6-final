import axios from 'axios';
import React, { useEffect } from 'react';
import { useParams } from 'react-router-dom';

const Mobile = () => {
  const params = useParams();
  console.log(params);

  useEffect(() => {
    if (params.id) {
      axios
        .get(`https://jsonplaceholder.typicode.com/posts/${params.id}`)
        .then(response => {
          console.log(response);
        })
        .catch(error => {
          console.log(error);
        });
    }
  }, [params.id]);
  return <div>Mobile selected by user is {params.brand}</div>;
};

export default Mobile;
