import React, { useEffect, useState } from 'react';
import './App.css';
import Main from './Main';
import axios from 'axios';

const App = () => {
  const [posts, setPosts] = useState([]);
  const [getPosts, setGetPosts] = useState(false);

  const [postsId, setPostId] = useState(1);
  const [post, setPost] = useState({});

  const [newPost, setNewPost] = useState({
    title: '',
    body: '',
    userId: 0,
  });

  const [newPostData, setNewPostData] = useState({});

  useEffect(() => {
    axios
      .get('https://jsonplaceholder.typicode.com/posts')
      .then(response => {
        const filteredPosts = response.data.slice(0, 10);
        setPosts(filteredPosts);
      })
      .catch(error => {
        console.log(error);
      });
  }, [getPosts]);

  // promise -- > should be resolved or rejected
  //  use inside then block
  // use inside the catch block

  useEffect(() => {
    axios
      .get(`https://jsonplaceholder.typicode.com/posts/${postsId}`)
      .then(response => {
        setPost(response.data);
      })
      .catch(error => {
        console.log(error);
      });
  }, [postsId]);

  const onInputChange = event => {
    setNewPost(prevState => {
      return { ...prevState, [event.target.name]: event.target.value };
    });
  };

  const createNewPost = () => {
    const postData = {
      title: newPost.title,
      body: newPost.body,
      userId: newPost.userId,
    };
    axios
      .post('https://jsonplaceholder.typicode.com/posts', postData)
      .then(response => {
        console.log(response);
        setNewPostData(response.data);
      })
      .catch(error => {
        console.log(error);
      });
  };

  const deletePost = postId => {
    axios
      .delete(`https://jsonplaceholder.typicode.com/posts/${postId}`)
      .then(response => {
        console.log(response);
      })
      .catch(error => {
        console.log(error);
      });
  };

  return (
    <div>
      <h1>Async operations with React using axios</h1>

      <button onClick={() => setGetPosts(prevState => !prevState)}>Get Posts</button>

      {posts &&
        posts.map(post => {
          return (
            <h3 key={post.id} onClick={() => deletePost(post.id)} style={{ cursor: 'pointer' }}>
              {post.id} {post.title}
            </h3>
          );
        })}

      <input type='number' value={postsId} onChange={event => setPostId(+event.target.value)} />

      {/* <h2>
        {post.id} {post.title}
      </h2> */}

      <br />
      <br />
      <br />

      <input type='text' placeholder='Title' name='title' onChange={onInputChange} />
      <br />

      <input type='text' placeholder='Body' name='body' onChange={onInputChange} />
      <br />

      <input type='number' placeholder='UserId' name='userId' onChange={onInputChange} />
      <br />

      <button onClick={createNewPost}>Create Post</button>

      {/* <h2>
        {newPostData.id} {newPostData.title} {newPostData.userId}
      </h2> */}
    </div>
  );
};

export default App;

// axios
