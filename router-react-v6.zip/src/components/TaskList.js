import React from 'react';
import TaskItem from './TaskItem';

const TaskList = props => {
  const { tasks, deleteTask, editTask, toggleTask } = props;
  return (
    <table>
      <thead>
        <tr>
          <th>Item</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {tasks.map(task => {
          return <TaskItem key={task.id} taskItem={task} deleteTask={deleteTask} editTask={editTask} toggleTask={toggleTask} />;
        })}
      </tbody>
    </table>
  );
};

export default TaskList;
